#!/usr/bin/env python3
# simulate_strategies.py

import os, uuid, hmac, hashlib, random, math
from statistics import mean
from dotenv import load_dotenv

load_dotenv()
SERVER_SEED = os.getenv("SERVER_SEED", "seed")
HOUSE_EDGE  = float(os.getenv("HOUSE_EDGE", "0.10"))

# Параметры игры (один кликовый шаг = +5%)
D_C        = 0.05
MAX_HIDE   = 2
HIDE_SHARE = 0.30
HIDE_FEE   = 0.05

def crash_point(server_seed, client_seed, game_id, edge):
    msg = (client_seed + game_id).encode()
    key = server_seed.encode()
    digest = hmac.new(key, msg, hashlib.sha256).hexdigest()
    h = int(digest[:13], 16)/(1<<52) or 1e-12
    return max(1.0, round(h**(-edge), 4))

def simulate(user_id, rounds, cashout_mul, hide_positions):
    """
    hide_positions: список кликов, в которых делаем спрятку
    cashout_mul: именно этот множитель ждём, и если его достигаем до краша — выходим
    """
    payouts = []
    for _ in range(rounds):
        game_id = uuid.uuid4().hex
        cp = crash_point(SERVER_SEED, str(user_id), game_id, HOUSE_EDGE)
        # на каком клике будет краш
        crash_click = max(1, int(math.ceil((cp-1)/D_C)))
        
        hidden = 0.0
        payout = 0.0
        
        # проходим шаги до min(crash, cashout) + 1
        for i in range(1, max(crash_click, 1) + 2):
            mult = 1 + D_C*i
            
            # прятка?
            if i in hide_positions:
                onhand = 1*mult - hidden
                amt    = onhand * HIDE_SHARE
                fee    = amt * HIDE_FEE
                hidden += (amt - fee)
            
            # если достигли cashout_mul и ещё не упали
            if mult >= cashout_mul and i < crash_click:
                payout = hidden + (1*mult - hidden)
                break
            
            # если упали
            if i == crash_click:
                payout = hidden
                break
        
        payouts.append(payout)
    return mean(payouts)

def main():
    rounds = int(input("Сколько раундов симулировать? → ").strip())
    uid    = input("user_id (ENTER для 12345): ").strip() or "12345"
    uid    = int(uid)
    
    print("\n=== Перебор стратегий ===")
    print("cashout_mul  | avg payout (%) при stake=1 и no hides")
    for cm in [1.02,1.05,1.10,1.20,1.50,2.0]:
        r = simulate(uid, rounds, cm, hide_positions=[])
        print(f"  {cm:>5.2f}      -> {r*100:>6.2f}%")
    
    print("\n=== Добавим по одной спрятке на 1 клике ===")
    hpos = [1]
    for cm in [1.02,1.05,1.10,1.20]:
        r = simulate(uid, rounds, cm, hide_positions=hpos)
        print(f"  cashout@{cm:<4} hide@{hpos} -> {r*100:>6.2f}%")

if __name__ == "__main__":
    main()
