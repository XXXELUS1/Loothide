// webapp/app.js

;(async () => {
  // === Инициализация Telegram Web App ===
  const tg = window.Telegram?.WebApp;
  let userId;
  if (window.location.search.includes("test")) {
    userId = 12345;
    console.log("Используем TEST userId =", userId);
  } else if (tg?.initDataUnsafe) {
    userId = tg.initDataUnsafe.user.id;
  } else {
    return alert("Запустите WebApp внутри Telegram или добавьте ?test=1");
  }

  // === Константы игры ===
  const API_BASE       = window.location.origin;
  const D_C            = 0.05;    // +5% множителя за каждый клик
  const MAX_HIDE       = 2;       // максимум спряток
  const HIDE_SHARE     = 0.30;    // 30% от onHand уходит в тайник
  const HIDE_FEE       = 0.10;    // 10% комиссии при спрятке
  const SPAWN_INTERVAL = 3000;    // интервал между спавном коинов, ms

  // === DOM-элементы ===
  const balanceEl    = document.getElementById("balance");
  const roundIdEl    = document.getElementById("roundId");
  const stakeInput   = document.getElementById("stakeInput");
  const quickBtns    = document.querySelectorAll("#quick-stakes button");
  const playBtn      = document.getElementById("playBtn");
  const startMenu    = document.getElementById("start-controls");
  const statusDiv    = document.getElementById("status");
  const multiplierEl = document.getElementById("multiplier");
  const onhandEl     = document.getElementById("onhand");
  const riskEl       = document.getElementById("risk");
  const hiddenEl     = document.getElementById("hidden");
  const gameField    = document.getElementById("game-field");
  const controlsDiv  = document.getElementById("controls");
  const hideBtn      = document.getElementById("hideBtn");
  const cashoutBtn   = document.getElementById("cashoutBtn");

  // === Состояние ===
  let stake      = 0;
  let gameId     = null;
  let crashPoint = 0;
  let clicks     = 0;
  let multiplier = 1;
  let hidden     = 0;
  let hideCount  = 0;
  let spawnTimer = null;

  // === Функция обновления баланса на экране ===
  async function refreshBalance() {
    try {
      const res = await fetch(`${API_BASE}/user/balance/${userId}`);
      if (!res.ok) throw new Error(res.status);
      const { balance } = await res.json();
      balanceEl.textContent = balance.toFixed(2);
    } catch (e) {
      console.error("refreshBalance:", e);
    }
  }
  // вызываем, не дожидаясь
  refreshBalance();

  // === Быстрые кнопки для ставки ===
  quickBtns.forEach(btn =>
    btn.onclick = () => { stakeInput.value = btn.dataset.value; }
  );

  // === Обновление HUD игры ===
  function updateStatus() {
    const onHand = stake * multiplier - hidden;
    // для визуального риска просто считаем: процент от crashPoint
    const riskPct = Math.min(1, (multiplier - 1) / (crashPoint - 1)) * 100;
    multiplierEl.textContent = `x${multiplier.toFixed(2)}`;
    onhandEl.textContent     = onHand.toFixed(2);
    riskEl.textContent       = `${riskPct.toFixed(1)}%`;
    hiddenEl.textContent     = hidden.toFixed(2);
  }

  // === Сброс интерфейса в главное меню ===
  function resetToMenu() {
    clearInterval(spawnTimer);
    gameField.innerHTML       = "";
    gameField.style.display   = "none";
    controlsDiv.style.display = "none";
    statusDiv.style.display   = "none";
    startMenu.style.display   = "flex";
    roundIdEl.textContent     = "—";
    stakeInput.value          = "";
    hideCount                 = 0;
    refreshBalance();
  }

  // === Спавн одного коина и его обработка ===
  function spawnCoin() {
    const coin = document.createElement("div");
    coin.className   = "coin";
    coin.textContent = "$";
    coin.style.left  = `${Math.random() * (gameField.clientWidth - 24)}px`;
    coin.onclick = () => {
      coin.remove();
      clicks++;
      // линейный рост множителя
      multiplier = +(1 + D_C * clicks).toFixed(2);

      // проверяем краш
      if (multiplier >= crashPoint) {
        handleCrash();
      } else {
        updateStatus();
      }
    };
    coin.addEventListener("animationend", () => coin.remove());
    gameField.appendChild(coin);
  }

  // === Обработка краша ===
  async function handleCrash() {
    clearInterval(spawnTimer);
    hideBtn.disabled = cashoutBtn.disabled = true;

    // отображаем сообщение о краше
    gameField.innerHTML = `
      <h2 style="color:#e74c3c; text-align:center; margin-top:2rem">
        💥 Краш на x${multiplier.toFixed(2)}
      </h2>`;

    // запрашиваем возврат спрятанного
    try {
      const res = await fetch(`${API_BASE}/game/cashout`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ game_id: gameId })
      });
      const data = await res.json();
      if (res.ok) {
        gameField.innerHTML += `
          <h3 style="color:#f1c40f; text-align:center">
            🗄️ Сохранено в тайнике: ${data.payout.toFixed(2)}
          </h3>`;
        await refreshBalance();
      } else {
        console.error("Crash cashout failed:", data);
      }
    } catch (e) {
      console.error("Crash cashout error:", e);
    }

    setTimeout(resetToMenu, 2000);
  }

  // === Начало игры ===
  playBtn.onclick = async () => {
    stake = parseFloat(stakeInput.value);
    if (isNaN(stake) || stake <= 0) {
      return alert("Введите корректную ставку");
    }

    try {
      // POST /game/start
      const r = await fetch(`${API_BASE}/game/start`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ user_id: userId, stake })
      });
      if (!r.ok) throw new Error(r.status);
      const { game_id, crash_point } = await r.json();
      gameId     = game_id;
      crashPoint = crash_point;

      roundIdEl.textContent = gameId.slice(0, 8);
      await refreshBalance();

      // переключаем UI
      startMenu.style.display   = "none";
      gameField.style.display   = "block";
      controlsDiv.style.display = "flex";
      statusDiv.style.display   = "block";

      // сброс счётчиков
      clicks     = 0;
      multiplier = 1;
      hidden     = 0;
      hideCount  = 0;
      hideBtn.disabled    = false;
      cashoutBtn.disabled = false;
      updateStatus();

      // старт спавна
      spawnTimer = setInterval(spawnCoin, SPAWN_INTERVAL);
    } catch (e) {
      console.error("startError:", e);
      alert("Не удалось начать игру");
    }
  };

  // === Спрятать часть onHand в тайник ===
  hideBtn.onclick = async () => {
    if (hideCount >= MAX_HIDE) {
      return alert(`Можно спрятать не более ${MAX_HIDE} раз`);
    }
    const onHand = +(stake * multiplier - hidden).toFixed(2);
    if (onHand <= 0) {
      return alert("Нечего прятать");
    }

    // считаем сумму спрятки и комиссию
    let amount = onHand * HIDE_SHARE;
    const fee  = amount * HIDE_FEE;
    amount      = +(amount - fee).toFixed(2);

    try {
      const r = await fetch(`${API_BASE}/game/hide`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ game_id: gameId, amount })
      });
      if (!r.ok) throw new Error(r.status);
      const { hidden: got } = await r.json();
      hidden += got;
      hideCount++;
      updateStatus();
    } catch (e) {
      console.error("hideError:", e);
      alert("Ошибка спрятки");
    }
  };

  // === Забрать onHand+hidden ===
  cashoutBtn.onclick = async () => {
    clearInterval(spawnTimer);
    hideBtn.disabled    = true;
    cashoutBtn.disabled = true;

    const onHand = +(stake * multiplier - hidden).toFixed(2);

    try {
      const res = await fetch(`${API_BASE}/game/cashout`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ game_id: gameId, amount: onHand })
      });
      const data = await res.json();
      if (!res.ok) {
        console.error("cashout failed:", data);
        alert(`Ошибка: ${data.detail || JSON.stringify(data)}`);
      } else {
        gameField.innerHTML = `
          <h2 style="color:#2ecc71; text-align:center; margin-top:2rem">
            🏆 Вы забрали ${data.payout.toFixed(2)}
          </h2>`;
        await refreshBalance();
      }
    } catch (e) {
      console.error("cashoutError:", e);
      gameField.innerHTML = `
        <h2 style="color:#e67e22; text-align:center; margin-top:2rem">
          Ошибка при выводе
        </h2>`;
    } finally {
      setTimeout(resetToMenu, 2000);
    }
  };

})();
