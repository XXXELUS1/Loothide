# backend/utils/crash.py

import hmac
import hashlib
import math
import os

# Жёстко фиксируем D_C для линейного роста (5% за клик)
D_C = float(os.getenv("D_C", 0.05))


def crash_point(server_seed: str, client_seed: str, game_id: str, house_edge: float) -> float:
    """
    Геометрический crash:
      - на каждом клике шанс краша p = d*(1−EDGE)/(EDGE + d*(1−EDGE))
      - r = uniform(0,1] из HMAC-SHA256 первых 52 бит
      - crash_tick = floor( ln(r)/ln(1−p) ) + 1
      - crash_point = 1 + D_C*(crash_tick−1)
    """
    # 1) HMAC-SHA256
    msg    = (client_seed + game_id).encode()
    key    = server_seed.encode()
    digest = hmac.new(key, msg, hashlib.sha256).hexdigest()

    # 2) первые 13 hex → 52 бита → r in (0,1]
    hash_int = int(digest[:13], 16)
    r = hash_int / float(1 << 52) or 1e-12

    # 3) вычисляем p
    d = D_C
    edge = house_edge
    p = (d * (1 - edge)) / (edge + d * (1 - edge))

    # 4) геометрическое число кликов до краша
    crash_tick = math.floor(math.log(r) / math.log(1 - p)) + 1
    if crash_tick < 1:
        crash_tick = 1

    # 5) линейный crash_point
    cp = 1 + d * (crash_tick - 1)
    return round(cp, 2)
