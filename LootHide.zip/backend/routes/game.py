import os, uuid
from datetime import datetime
from pydantic import BaseModel
from fastapi import APIRouter, HTTPException
from backend.database import db
from fastapi import HTTPException
from backend.utils.crash import crash_point
from backend.models import (
    StartReq, StartResp,
    StatusResp, ActionReq,
    HideResp, CashoutResp
)

router = APIRouter()

SEED       = os.getenv("SERVER_SEED", "")
HOUSE_EDGE = float(os.getenv("HOUSE_EDGE", 0.10))

class StartReq(BaseModel):
    user_id: int
    stake: float

class StartResp(BaseModel):
    game_id: str
    crash_point: float   

@router.post("/game/start", response_model=StartResp)
async def game_start(req: StartReq):
    # проверка пользователя и баланса…
    # генерируем game_id
    game_id = uuid.uuid4().hex

    # вызываем новую функцию crash_point
    crash = crash_point(SEED, str(req.user_id), game_id, HOUSE_EDGE)

    # сохраняем раунд, списываем ставку…
    await db.games.insert_one({
        "_id":            game_id,
        "user_id":        req.user_id,
        "stake":          req.stake,
        "crash_point":    crash,
        "current_amount": req.stake,
        "hidden_amount":  0.0,
        "status":         "active",
        "created_at":     datetime.utcnow(),
    })
    await db.users.update_one(
        {"user_id": req.user_id},
        {"$inc": {"balance": -req.stake}}
    )

    return StartResp(game_id=game_id, crash_point=crash)

@router.get("/status/{game_id}", response_model=StatusResp)
async def game_status(game_id: str):
    g = await db.games.find_one({"_id": game_id})
    if not g:
        raise HTTPException(404, "Game not found")
    return StatusResp(
        game_id        = game_id,
        status         = g["status"],
        crash_point    = g["crash_point"],
        current_amount = g["current_amount"],
        hidden_amount  = g["hidden_amount"],
    )


@router.post("/hide", response_model=HideResp)
async def game_hide(req: ActionReq):
    g = await db.games.find_one({"_id": req.game_id})
    if not g or g["status"] != "active":
        raise HTTPException(400, "Invalid game")
    amt = req.amount or 0.0
    fee = round(amt * HOUSE_EDGE, 2)
    hidden = round(amt - fee, 2)
    await db.games.update_one(
        {"_id": req.game_id},
        {"$inc": {"current_amount": -amt, "hidden_amount": hidden}}
    )
    return HideResp(hidden=hidden, fee=fee)


@router.post("/cashout", response_model=CashoutResp)
async def game_cashout(req: ActionReq):
    g = await db.games.find_one({"_id": req.game_id})
    if not g:
        raise HTTPException(404, "Game not found")
    if g["status"] != "active":
        raise HTTPException(400, "Already finished")

    # Если пользователь сам нажал «Забрать» — в req.amount приходит число,
    # в остальных случаях (краш) req.amount == None
    if req.amount is None:
        # краш: возвращаем только спрятанное
        payout = g.get("hidden_amount", 0.0)
        new_status = "crashed"
    else:
        # ручной кешаут — возвращаем on-hand PLUS спрятанное
        payout = req.amount + g.get("hidden_amount", 0.0)
        new_status = "cashed_out"

    payout = round(payout, 2)

    # начисляем пользователю
    await db.users.update_one(
        {"user_id": g["user_id"]},
        {"$inc": {"balance": payout}}
    )
    # помечаем раунд и сбрасываем спрятанное
    await db.games.update_one(
        {"_id": req.game_id},
        {"$set": {
            "status": new_status,
            "payout": payout,
            "hidden_amount": 0.0
        }}
    )

    return CashoutResp(payout=payout)